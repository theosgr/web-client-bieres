API utilisé :

Brewery DB API (bière et bar dans le monde)
OpenweatherMap(météo)
