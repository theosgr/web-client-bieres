import useBiereApi from "../apibiere.js";

Vue.component("bieres", {
  template: `
  <table class="striped">
       <tbody>
            <tr> <td>  </td> <td> {{bieres.}} </td></tr>
            <tr> <td>  </td> <td> {{}} </td></tr>
      </tbody>
  </table>`
});
