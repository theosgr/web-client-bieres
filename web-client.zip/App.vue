<template>
<html lang="fr">
  <head>
    <meta charset="UTF-8">
    <title>WhichBeer</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="assets/vendor/materializeDesign/css/materialize.css">
    <script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/vue"></script>
  </head>

  <body>
    <div class="container">
      <div class="row">
        <app class="col-12"></app>
      </div>
      <div id="app"></div>
    </div>

    <script src="assets/vendor/materializeDesign/js/materialize.js"></script>
    <script type="module" src="src/apiville.js"></script>
    <script type="module" src="src/apibieres.js"></script>
    <script type="module" src="src/components/bieres.js"></script>
    <script type="module" src="src/components/search.js"></script>
    <script type="module" src="src/components/meteo.js"></script>
    <script type="module" src="src/components/app.js"></script>
    <script type="module" src="src/main.js"></script>
  </body>
</html>
</template>

<script>
import HelloWorld from "./components/HelloWorld";

export default {
  name: "App",
  components: {
    HelloWorld
  }
};
</script>


